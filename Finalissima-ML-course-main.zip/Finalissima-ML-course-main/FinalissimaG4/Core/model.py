import timm
import torch
import os
from Config.config import Config
from Core.shufflenet import ShuffleNetV2
from Core.resnetse import ResNet18_SE


class ModelManager:
    def __init__(self):
        # ABLATION: RESNET18 + SE
        if Config.MODEL_NAME == "resnetse":
            self.model = ResNet18_SE(
                num_classes=Config.NUM_CLASSES,
                pretrained=True
            )
        # SHUFFLENET
        elif Config.MODEL_NAME == "shufflenet":
            self.model = ShuffleNetV2(
                num_classes=Config.NUM_CLASSES,
                pretrained=True
            )
        # OTHER MODELS 
        else:
            self.model = timm.create_model(
                Config.MODEL_NAME,
                pretrained=True,   # ImageNet
                num_classes=Config.NUM_CLASSES
            )

        # LOAD PRETRAINED KAGGLE
        if not Config.PRETRAIN_STAGE:
            ckpt_path = f"pretrained_{Config.MODEL_NAME}.pth"
            if not os.path.exists(ckpt_path):
                raise FileNotFoundError(f"{ckpt_path} not found")

            print(f"Loading pretrained Kaggle weights: {ckpt_path}")
            state = torch.load(ckpt_path, map_location=Config.DEVICE)

            # remove classifier 2-class
            filtered = {}
            for k, v in state.items():
                # REMOVE classifier head (2-class)
                if k.startswith(("backbone.fc", "fc")):
                    continue
                if "classifier" in k:
                    continue
                if Config.USE_RESNET_SE and "se" in k.lower(): # resnet se
                    continue

                filtered[k] = v

            self.model.load_state_dict(filtered, strict=False)

            # freeze early stages
            self.freeze_early_stages()

        self.model.to(Config.DEVICE)

    # FREEZE 
    def freeze_early_stages(self):
        print("🔒 Freeze early backbone stages")

        for name, param in self.model.named_parameters():
            # RESNET
            if Config.USE_RESNET_SE:
                # Freeze stem + layer1 only
                if name.startswith(("backbone.conv1", "backbone.bn1", "backbone.layer1")):
                    param.requires_grad = False
                else:
                    param.requires_grad = True
            # SHUFFLENET
            elif Config.MODEL_NAME == "shufflenet":
                    if name.startswith(("backbone.conv1", "backbone.stage2")):
                        param.requires_grad = False
                    else:
                        param.requires_grad = True
            # EFFICIENTNET / MOBILENET 
            else:
                if any(k in name for k in ["conv_stem", "blocks.0", "blocks.1"]):
                    param.requires_grad = False
                else:
                    param.requires_grad = True

    def unfreezer(self):
        print("🔓 Unfreeze all layers")
        for p in self.model.parameters():
            p.requires_grad = True

    def get_model(self):
        return self.model
